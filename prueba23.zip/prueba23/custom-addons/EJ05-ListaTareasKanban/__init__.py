# -*- coding: utf-8 -*-
# No hay nada aqui, porque no vamos a cargar ningun modelo (el modulo solo crea
# vistas sobre modelos ya existentes)