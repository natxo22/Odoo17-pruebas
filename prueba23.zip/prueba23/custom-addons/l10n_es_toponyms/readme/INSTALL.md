Para instalar este módulo, son necesarios los módulos *base_location* y
*base_location_geonames_import*, disponibles en:

<https://github.com/OCA/partner-contact>
