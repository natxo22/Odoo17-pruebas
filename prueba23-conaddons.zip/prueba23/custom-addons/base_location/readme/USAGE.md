1.  Access a partner record
2.  Fill the field *Location completion*
3.  Information about country, state, city and zip will be filled
    automatically
